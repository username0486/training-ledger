import { TrendingUp, TrendingDown, Minus, Info, Play } from 'lucide-react';
import { TopBar } from '../components/TopBar';
import { Card } from '../components/Card';
import { Button } from '../components/Button';
import { Pill } from '../components/Pill';
import { Workout } from '../types';
import { formatDate } from '../utils/storage';

interface WorkoutSummaryScreenProps {
  workout: Workout;
  isJustCompleted?: boolean;
  onBack: () => void;
  onStartAgain: () => void;
  onViewExerciseHistory?: (exerciseName: string) => void;
}

export function WorkoutSummaryScreen({
  workout,
  isJustCompleted = false,
  onBack,
  onStartAgain,
  onViewExerciseHistory,
}: WorkoutSummaryScreenProps) {
  return (
    <div className="flex flex-col h-full">
      <TopBar title="Summary" onBack={onBack} />

      <div className="flex-1 overflow-y-auto">
        <div className="max-w-2xl mx-auto p-5 space-y-6">
          {/* Workout info */}
          <div>
            <h2 className="text-2xl mb-2">{workout.name}</h2>
            <p className="text-text-muted">
              {formatDate(workout.endTime || workout.startTime)} · {workout.exercises.length} exercises
            </p>
          </div>

          {/* Check for regressions - only show when just completed */}
          {isJustCompleted && workout.exercises.some(ex => {
            const avgWeight = ex.sets.reduce((sum, set) => sum + set.weight, 0) / ex.sets.length;
            return avgWeight < 50; // Mock regression check
          }) && (
            <Card className="bg-accent/5 border-accent/20">
              <div className="flex items-start gap-3">
                <Info className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                <div className="flex-1 min-w-0">
                  <p className="text-text-primary mb-1">Performance note</p>
                  <p className="text-text-muted">
                    Some exercises had lower weights than previous sessions.
                  </p>
                </div>
              </div>
            </Card>
          )}

          {/* Exercise breakdown */}
          <div className="space-y-4">
            {workout.exercises.map((exercise) => {
              const totalVolume = exercise.sets.reduce((sum, set) => sum + (set.weight * set.reps), 0);
              const avgWeight = exercise.sets.reduce((sum, set) => sum + set.weight, 0) / exercise.sets.length;
              const suggestion = getSuggestion(avgWeight, exercise.sets.length);

              return (
                <Card 
                  key={exercise.id} 
                  gradient
                  onClick={onViewExerciseHistory ? () => onViewExerciseHistory(exercise.name) : undefined}
                  className={onViewExerciseHistory ? "cursor-pointer" : ""}
                >
                  <h3 className="mb-4">{exercise.name}</h3>

                  {/* Sets */}
                  <div className="space-y-2 mb-4">
                    {exercise.sets.map((set, index) => (
                      <div
                        key={set.id}
                        className="flex items-center justify-between p-3 bg-surface rounded-lg"
                      >
                        <span className="text-text-muted">Set {index + 1}</span>
                        <div className="flex items-center gap-2">
                          <span>{set.weight} kg</span>
                          <span className="text-text-muted">×</span>
                          <span>{set.reps} reps</span>
                          {set.restDuration !== undefined && set.restDuration > 0 && (
                            <>
                              <span className="text-text-muted/40">·</span>
                              <span className="text-text-muted/60 text-sm tabular-nums">
                                {Math.floor(set.restDuration / 60)}:{(set.restDuration % 60).toString().padStart(2, '0')} rest
                              </span>
                            </>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Stats */}
                  <div className="flex gap-4 mb-4 text-text-muted">
                    <div>
                      <span className="text-xs uppercase tracking-wide">Total Volume</span>
                      <p className="text-text-primary">{totalVolume.toFixed(0)} kg</p>
                    </div>
                    <div>
                      <span className="text-xs uppercase tracking-wide">Avg Weight</span>
                      <p className="text-text-primary">{avgWeight.toFixed(1)} kg</p>
                    </div>
                  </div>

                  {/* Next time suggestion */}
                  <div className="p-4 bg-surface rounded-lg border border-border-subtle">
                    <p className="text-xs uppercase tracking-wide text-text-muted mb-2">Next Time</p>
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2 flex-1">
                        {suggestion.icon}
                        <p>{suggestion.text}</p>
                      </div>
                      <Pill variant="accent">{suggestion.suggestedWeight} kg</Pill>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>

          {/* Actions */}
          <div className="space-y-3 pb-6">
            {!isJustCompleted && (
              <Button variant="primary" onClick={onStartAgain} className="w-full">
                <Play className="w-4 h-4 mr-2 inline" />
                Start This Workout
              </Button>
            )}
            {isJustCompleted && (
              <Button variant="neutral" onClick={onBack} className="w-full">
                Done
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function getSuggestion(avgWeight: number, numSets: number): {
  text: string;
  suggestedWeight: number;
  icon: React.ReactNode;
} {
  // Simple mock logic for suggestions
  if (numSets >= 4 && avgWeight > 0) {
    return {
      text: 'All sets completed',
      suggestedWeight: Math.round((avgWeight + 2.5) * 2) / 2,
      icon: <TrendingUp className="w-4 h-4 text-accent" />,
    };
  }
  
  if (numSets < 3) {
    return {
      text: 'Same as last time',
      suggestedWeight: Math.round(avgWeight * 2) / 2,
      icon: <Minus className="w-4 h-4 text-text-muted" />,
    };
  }

  return {
    text: 'Match or beat your last performance',
    suggestedWeight: Math.round(avgWeight * 2) / 2,
    icon: <Minus className="w-4 h-4 text-text-muted" />,
  };
}