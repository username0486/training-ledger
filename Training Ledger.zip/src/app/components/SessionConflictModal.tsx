import { Modal } from './Modal';
import { Button } from './Button';

interface SessionConflictModalProps {
  isOpen: boolean;
  onClose: () => void;
  sessionType: 'exercise' | 'workout';
  sessionName: string;
  onResume: () => void;
  onDiscard: () => void;
  onSaveAndContinue?: () => void;
}

export function SessionConflictModal({
  isOpen,
  onClose,
  sessionType,
  sessionName,
  onResume,
  onDiscard,
  onSaveAndContinue,
}: SessionConflictModalProps) {
  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <div className="space-y-6">
        <div>
          <h2 className="text-center mb-2">Session in Progress</h2>
          <p className="text-center text-[--color-text-secondary]">
            You have an incomplete {sessionType} entry for <span className="text-[--color-text-primary]">{sessionName}</span>
          </p>
        </div>

        <div className="space-y-3">
          <Button onClick={onResume} variant="primary" className="w-full">
            Resume Session
          </Button>
          
          {onSaveAndContinue && (
            <Button onClick={onSaveAndContinue} variant="secondary" className="w-full">
              Save & Record New
            </Button>
          )}
          
          <Button onClick={onDiscard} variant="ghost" className="w-full text-[--color-error]">
            Discard Session
          </Button>
          
          <Button onClick={onClose} variant="ghost" className="w-full">
            Cancel
          </Button>
        </div>
      </div>
    </Modal>
  );
}